# NOVA DEVELOPMENT — plateforme Web mondiale (socle technique v1)

Ce dépôt contient un socle logiciel exécutable : API Node.js/Express, PostgreSQL/Prisma,
authentification, rôles, ressources collaboratives, assistant IA configurable, recherche
scientifique OpenAlex/Crossref et interface Web multilingue de démarrage.

## État réel du livrable
- Le code source et les configurations sont fournis.
- Les données sont persistées dans PostgreSQL.
- L'inscription, la connexion, les rôles et les opérations CRUD sont implémentés.
- Les connecteurs IA et scientifiques fonctionnent après configuration de leurs clés/accès.
- Le frontend est une première interface fonctionnelle, à enrichir pour les 10 modules complets.
- Aucun compte cloud, nom de domaine, clé API ni serveur public n'est inclus.
- Le compte propriétaire doit être créé par la procédure d'amorçage décrite ci-dessous.

Ce socle n'est pas encore un produit audité ou prêt à accueillir des données sensibles à grande échelle.
Un audit indépendant, des tests de charge, une revue juridique et un durcissement opérationnel sont requis avant ouverture publique.

## Prérequis
- Node.js 20+
- Docker Desktop ou Docker Engine + Compose
- Un terminal
- Pour l'IA : clé d'un fournisseur compatible avec l'API OpenAI (facultatif au démarrage)

## Démarrage local
1. Copier `backend/.env.example` vers `backend/.env` et définir au minimum `JWT_SECRET`,
   `DATABASE_URL`, `CORS_ORIGIN`, `OWNER_EMAIL` et `OWNER_PASSWORD`.
2. Depuis la racine : `docker compose up -d db`
3. `cd backend && npm install`
4. `npx prisma generate && npx prisma migrate dev --name init`
5. `npm run owner:bootstrap`
6. `npm run dev`
7. Dans un autre terminal : ouvrir `frontend/index.html` dans un navigateur ou servir le dossier
   avec `npx serve frontend`. Configurer l'URL API dans le panneau de connexion si nécessaire
   (par défaut `http://localhost:4000/api`).

## Variables principales
Voir `backend/.env.example`. Ne jamais publier `.env`, les mots de passe ou les clés API.
Générer un JWT_SECRET long et aléatoire. Utiliser HTTPS en production.

## API
- `GET /api/health`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me` (authentifié)
- `GET /api/resources/:type`
- `POST /api/resources/:type`
- `GET /api/resources/:type/:id`
- `PATCH /api/resources/:type/:id`
- `DELETE /api/resources/:type/:id`
- `POST /api/ai/chat` (authentifié, fournisseur configuré)
- `GET /api/research/search?q=...` (authentifié)
- `GET /api/admin/overview` (OWNER/ADMIN)

Types de ressources autorisés : problems, ideas, projects, experts, funding, courses, impact.
Les permissions de propriété sont vérifiées sur les opérations de modification/suppression.
Les routes administratives sont réservées aux rôles OWNER et ADMIN.

## Déploiement
Consulter `deploy/DEPLOYMENT.md`. Le déploiement nécessite un fournisseur cloud choisi,
un domaine, des secrets, une base PostgreSQL managée ou administrée, TLS et des sauvegardes.
Ne pas utiliser des données réelles sensibles avant audit.

## Langues
Le frontend contient un sélecteur pour les 14 langues validées. Cette version traduit les libellés
principaux de navigation et certains éléments d'interface. La traduction complète de tous les contenus,
messages système et emails reste une tâche de localisation à valider par des locuteurs natifs.

## Propriété intellectuelle
Conserver le dépôt Git, le compte cloud, le domaine, les comptes API et les sauvegardes sous le contrôle
de la société. Les contrats des prestataires doivent régler la cession des droits sur les créations,
les licences tierces, la confidentialité et la réversibilité.


## NOVA PAYMENTS
Voir `deploy/NOVA_PAYMENTS_IMPLEMENTATION.md` pour le plan technique, les règles de sécurité et l’état exact des adaptateurs. Les prestataires de paiement sont désactivés tant que les accès marchands, les webhooks vérifiés et les tests sandbox ne sont pas terminés.
