import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { prisma } from './db.js';
const email=process.env.OWNER_EMAIL?.toLowerCase();
const password=process.env.OWNER_PASSWORD;
if(!email || !password || password.length<16){
  console.error('Définissez OWNER_EMAIL et OWNER_PASSWORD (16 caractères minimum) dans backend/.env.');
  process.exit(1);
}
try{
  const existing=await prisma.user.findUnique({where:{email}});
  if(existing){
    if(existing.role!=='OWNER') await prisma.user.update({where:{email},data:{role:'OWNER'}});
    console.log('Le compte propriétaire existe déjà : rôle OWNER vérifié. Aucun mot de passe modifié.');
  }else{
    const passwordHash=await bcrypt.hash(password,12);
    await prisma.user.create({data:{email,passwordHash,displayName:'NOVA Owner',role:'OWNER',preferredLanguage:'fr'}});
    console.log(`Compte propriétaire créé pour ${email}. Conservez les identifiants dans un gestionnaire sécurisé.`);
  }
}catch(e){console.error(e);process.exitCode=1;}finally{await prisma.$disconnect();}
