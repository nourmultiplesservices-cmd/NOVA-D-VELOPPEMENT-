import { createWaveProvider } from './providers/wave.provider.js';
import { createOrangeMoneyProvider } from './providers/orange-money.provider.js';
import { createMtnMomoProvider } from './providers/mtn-momo.provider.js';
import { createCardGatewayProvider } from './providers/card-gateway.provider.js';

// Each provider is independently enabled only after merchant approval, sandbox
// validation, webhook verification and production credentials are configured.
export function getProvider(code) {
  const providers = {
    WAVE: createWaveProvider(),
    ORANGE_MONEY: createOrangeMoneyProvider(),
    MTN_MOMO: createMtnMomoProvider(),
    CARD_GATEWAY: createCardGatewayProvider(),
  };
  const provider = providers[code];
  if (!provider) throw Object.assign(new Error('Moyen de paiement inconnu.'), { status: 400 });
  if (!provider.isConfigured()) throw Object.assign(new Error('Ce moyen de paiement n’est pas encore activé en production.'), { status: 503 });
  return provider;
}
