// CARD_GATEWAY: adapter contract. Deliberately disabled until credentials,
// merchant approval and provider-specific webhook verification are implemented.
export function createCardGatewayProvider() {
  return {
    code: 'CARD_GATEWAY',
    isConfigured() { return false; },
    async createCheckout(_payment, _customer) {
      throw new Error('CARD_GATEWAY adapter not configured.');
    },
    async verifyWebhook(_request) {
      throw new Error('CARD_GATEWAY webhook verification not implemented.');
    },
    async getPaymentStatus(_providerPaymentId) {
      throw new Error('CARD_GATEWAY status lookup not implemented.');
    },
  };
}
