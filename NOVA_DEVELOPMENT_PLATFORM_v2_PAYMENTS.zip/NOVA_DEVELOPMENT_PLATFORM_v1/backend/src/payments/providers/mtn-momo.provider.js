// MTN_MOMO: adapter contract. Deliberately disabled until credentials,
// merchant approval and provider-specific webhook verification are implemented.
export function createMtnMomoProvider() {
  return {
    code: 'MTN_MOMO',
    isConfigured() { return false; },
    async createCheckout(_payment, _customer) {
      throw new Error('MTN_MOMO adapter not configured.');
    },
    async verifyWebhook(_request) {
      throw new Error('MTN_MOMO webhook verification not implemented.');
    },
    async getPaymentStatus(_providerPaymentId) {
      throw new Error('MTN_MOMO status lookup not implemented.');
    },
  };
}
