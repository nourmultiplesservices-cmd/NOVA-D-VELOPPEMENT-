// ORANGE_MONEY: adapter contract. Deliberately disabled until credentials,
// merchant approval and provider-specific webhook verification are implemented.
export function createOrangeMoneyProvider() {
  return {
    code: 'ORANGE_MONEY',
    isConfigured() { return false; },
    async createCheckout(_payment, _customer) {
      throw new Error('ORANGE_MONEY adapter not configured.');
    },
    async verifyWebhook(_request) {
      throw new Error('ORANGE_MONEY webhook verification not implemented.');
    },
    async getPaymentStatus(_providerPaymentId) {
      throw new Error('ORANGE_MONEY status lookup not implemented.');
    },
  };
}
