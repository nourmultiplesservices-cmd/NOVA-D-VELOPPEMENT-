// WAVE: adapter contract. Deliberately disabled until credentials,
// merchant approval and provider-specific webhook verification are implemented.
export function createWaveProvider() {
  return {
    code: 'WAVE',
    isConfigured() { return false; },
    async createCheckout(_payment, _customer) {
      throw new Error('WAVE adapter not configured.');
    },
    async verifyWebhook(_request) {
      throw new Error('WAVE webhook verification not implemented.');
    },
    async getPaymentStatus(_providerPaymentId) {
      throw new Error('WAVE status lookup not implemented.');
    },
  };
}
