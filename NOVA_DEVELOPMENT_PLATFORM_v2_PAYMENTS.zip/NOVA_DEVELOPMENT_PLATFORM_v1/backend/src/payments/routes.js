import { Router } from 'express';
import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { prisma } from '../db.js';
import { authenticate } from '../middleware.js';
import { getProvider } from './provider-registry.js';

const router = Router();
const checkoutSchema = z.object({
  planCode: z.enum(['NOVA_PRO','NOVA_BUSINESS']),
  interval: z.enum(['MONTHLY','YEARLY']),
  provider: z.enum(['WAVE','ORANGE_MONEY','MTN_MOMO','CARD_GATEWAY']),
  currency: z.string().length(3).default('XOF'),
  country: z.string().length(2).optional(),
}).strict();

router.get('/plans', async (_req,res,next) => {
  try {
    const plans = await prisma.plan.findMany({ where: { active: true }, orderBy: { code: 'asc' } });
    res.json({ plans: plans.map(p => ({ ...p, monthlyAmount: p.monthlyAmount?.toString() ?? null, yearlyAmount: p.yearlyAmount?.toString() ?? null })) });
  } catch (e) { next(e); }
});

router.post('/checkout', authenticate, async (req,res,next) => {
  try {
    const input = checkoutSchema.parse(req.body);
    const plan = await prisma.plan.findUnique({ where: { code: input.planCode } });
    if (!plan || !plan.active) return res.status(404).json({ error: 'Offre indisponible.' });
    if (input.currency !== plan.currency) return res.status(400).json({ error: 'Devise non disponible pour cette offre.' });
    const amount = input.interval === 'MONTHLY' ? plan.monthlyAmount : plan.yearlyAmount;
    if (amount == null || amount <= 0n) return res.status(400).json({ error: 'Tarif non configuré.' });
    const provider = getProvider(input.provider);
    const idempotencyKey = randomUUID();
    const payment = await prisma.payment.create({ data: {
      userId: req.user.id, planId: plan.id, provider: input.provider,
      amount, currency: plan.currency, billingInterval: input.interval, idempotencyKey, status: 'CREATED'
    }});
    // Provider adapters must return a hosted checkout URL and external ID.
    const checkout = await provider.createCheckout(payment, { email: req.user.email, country: input.country });
    const updated = await prisma.payment.update({ where: { id: payment.id }, data: {
      status: 'PENDING', checkoutUrl: checkout.checkoutUrl, externalReference: checkout.externalReference, providerPaymentId: checkout.providerPaymentId
    }});
    res.status(201).json({ paymentId: updated.id, status: updated.status, checkoutUrl: updated.checkoutUrl });
  } catch (e) {
    if (e instanceof z.ZodError) return res.status(400).json({ error: 'Données invalides.', details: e.flatten() });
    if (e.status) return res.status(e.status).json({ error: e.message });
    next(e);
  }
});

router.get('/mine', authenticate, async (req,res,next) => {
  try {
    const payments = await prisma.payment.findMany({ where: { userId: req.user.id }, orderBy: { createdAt: 'desc' }, take: 50, select: { id:true, provider:true, status:true, amount:true, currency:true, billingInterval:true, createdAt:true, paidAt:true } });
    const subscriptions = await prisma.subscription.findMany({ where: { userId: req.user.id }, include: { plan: { select: { code:true, name:true } } }, orderBy: { createdAt: 'desc' } });
    res.json({ payments, subscriptions });
  } catch (e) { next(e); }
});

export default router;
