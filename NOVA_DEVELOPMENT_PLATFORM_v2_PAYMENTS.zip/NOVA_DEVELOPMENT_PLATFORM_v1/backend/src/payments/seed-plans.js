import 'dotenv/config';
import { prisma } from '../db.js';

const plans = [
  { code:'NOVA_FREE', name:'NOVA Free', currency:'XOF', monthlyAmount:0n, yearlyAmount:0n, limits:{ aiRequestsPerDay:5, advancedResearch:false } },
  { code:'NOVA_PRO', name:'NOVA Pro', currency:'XOF', monthlyAmount:5000n, yearlyAmount:50000n, limits:{ aiRequestsPerDay:100, advancedResearch:true } },
  { code:'NOVA_BUSINESS', name:'NOVA Business', currency:'XOF', monthlyAmount:20000n, yearlyAmount:200000n, limits:{ aiRequestsPerDay:500, advancedResearch:true, collaboration:true } },
];
for (const plan of plans) await prisma.plan.upsert({ where:{code:plan.code}, create:plan, update:plan });
await prisma.$disconnect();
console.log('NOVA plans seeded.');
