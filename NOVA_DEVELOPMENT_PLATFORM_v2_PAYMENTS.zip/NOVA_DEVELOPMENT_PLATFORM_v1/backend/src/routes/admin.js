import { Router } from 'express';
import { prisma } from '../db.js';
import { authenticate, allowRoles } from '../middleware.js';
const router = Router();
router.use(authenticate, allowRoles('OWNER','ADMIN'));
router.get('/overview', async (req,res,next)=>{
  try{
    const [users,resources,byType,recentAudit] = await Promise.all([
      prisma.user.count(), prisma.resource.count(),
      prisma.resource.groupBy({by:['type'],_count:{_all:true}}),
      prisma.auditLog.findMany({orderBy:{createdAt:'desc'},take:20,include:{actor:{select:{email:true,displayName:true}}}})
    ]);
    res.json({users,resources,byType,recentAudit});
  }catch(e){next(e);}
});
router.get('/users', async (req,res,next)=>{
  try{
    const users=await prisma.user.findMany({select:{id:true,email:true,displayName:true,role:true,isActive:true,createdAt:true},orderBy:{createdAt:'desc'},take:100});
    res.json({users});
  }catch(e){next(e);}
});
router.patch('/users/:id/role', async (req,res,next)=>{
  try{
    if(req.user.role!=='OWNER') return res.status(403).json({error:'Seul le propriétaire peut modifier les rôles.'});
    const allowed=['USER','EXPERT','MODERATOR','ADMIN'];
    const role=String(req.body.role||'');
    if(!allowed.includes(role)) return res.status(400).json({error:'Rôle non autorisé.'});
    if(req.params.id===req.user.id) return res.status(400).json({error:'Le rôle du propriétaire ne peut pas être modifié ici.'});
    const user=await prisma.user.update({where:{id:req.params.id},data:{role}});
    await prisma.auditLog.create({data:{actorId:req.user.id,action:'USER_ROLE_UPDATED',target:user.id,ip:req.ip}});
    res.json({id:user.id,role:user.role});
  }catch(e){next(e);}
});
export default router;
