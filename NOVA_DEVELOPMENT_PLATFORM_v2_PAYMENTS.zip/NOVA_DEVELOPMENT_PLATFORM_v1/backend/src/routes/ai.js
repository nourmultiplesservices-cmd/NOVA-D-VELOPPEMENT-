import { Router } from 'express';
import { authenticate } from '../middleware.js';
const router = Router();
router.use(authenticate);
router.post('/chat', async (req,res) => {
  const { messages, language='fr' } = req.body || {};
  if (!Array.isArray(messages) || messages.length < 1 || messages.length > 30) return res.status(400).json({error:'Fournissez entre 1 et 30 messages.'});
  if (!process.env.AI_BASE_URL || !process.env.AI_API_KEY || !process.env.AI_MODEL) return res.status(503).json({error:'Le fournisseur IA n’est pas encore configuré. Ajoutez AI_BASE_URL, AI_API_KEY et AI_MODEL dans les secrets du serveur.'});
  const safeMessages = messages.map(m => ({role:['user','assistant'].includes(m.role)?m.role:'user',content:String(m.content || '').slice(0,12000)}));
  try {
    const controller = new AbortController();
    const timeout = setTimeout(()=>controller.abort(), Number(process.env.AI_TIMEOUT_MS)||45000);
    const response = await fetch(`${process.env.AI_BASE_URL.replace(/\/$/,'')}/chat/completions`, {
      method:'POST', signal:controller.signal,
      headers:{'Authorization':`Bearer ${process.env.AI_API_KEY}`,'Content-Type':'application/json'},
      body:JSON.stringify({model:process.env.AI_MODEL,temperature:0.2,messages:[
        {role:'system',content:`You are NOVA AI, a careful multilingual research assistant. Respond in language ${language}. Distinguish evidence from hypotheses. Never fabricate citations. If sources are not supplied, say that verification is needed.`},
        ...safeMessages
      ]})
    });
    clearTimeout(timeout);
    const data = await response.json().catch(()=>({}));
    if (!response.ok) return res.status(502).json({error:'Le fournisseur IA a refusé la requête.',providerStatus:response.status});
    res.json({answer:data.choices?.[0]?.message?.content || 'Aucune réponse reçue.',model:data.model || process.env.AI_MODEL});
  } catch(e) { res.status(502).json({error:e.name==='AbortError'?'Délai IA dépassé.':'Service IA momentanément indisponible.'}); }
});
export default router;
