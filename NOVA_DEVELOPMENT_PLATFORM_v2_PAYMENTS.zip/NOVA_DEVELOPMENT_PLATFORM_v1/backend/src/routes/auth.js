import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { prisma } from '../db.js';
import { authenticate } from '../middleware.js';
import { registerSchema, loginSchema } from '../validation.js';

const router = Router();
function issueToken(user) {
  return jwt.sign({ sub: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '8h', issuer: 'nova-development' });
}
router.post('/register', async (req,res,next) => {
  try {
    const parsed = registerSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Données invalides.', details: parsed.error.flatten() });
    const { email, password, displayName, preferredLanguage } = parsed.data;
    const normalized = email.toLowerCase();
    if (await prisma.user.findUnique({ where: { email: normalized } })) return res.status(409).json({ error: 'Cette adresse est déjà utilisée.' });
    const passwordHash = await bcrypt.hash(password, 12);
    const user = await prisma.user.create({ data: { email: normalized, passwordHash, displayName, preferredLanguage } });
    const token = issueToken(user);
    res.status(201).json({ token, user: { id:user.id, email:user.email, displayName:user.displayName, role:user.role, preferredLanguage:user.preferredLanguage } });
  } catch (e) { next(e); }
});
router.post('/login', async (req,res,next) => {
  try {
    const parsed = loginSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Identifiants invalides.' });
    const user = await prisma.user.findUnique({ where: { email: parsed.data.email.toLowerCase() } });
    if (!user || !user.isActive || !(await bcrypt.compare(parsed.data.password, user.passwordHash))) return res.status(401).json({ error: 'Email ou mot de passe incorrect.' });
    res.json({ token: issueToken(user), user: { id:user.id, email:user.email, displayName:user.displayName, role:user.role, preferredLanguage:user.preferredLanguage } });
  } catch (e) { next(e); }
});
router.get('/me', authenticate, async (req,res) => res.json({ user:req.user }));
export default router;
