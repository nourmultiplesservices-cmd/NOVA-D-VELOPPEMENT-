import { Router } from 'express';
import { authenticate } from '../middleware.js';
const router = Router();
router.use(authenticate);
router.get('/search', async (req,res) => {
  const q = String(req.query.q || '').trim().slice(0,300);
  if (q.length < 2) return res.status(400).json({error:'La recherche doit contenir au moins 2 caractères.'});
  try {
    const mailto = process.env.OPENALEX_MAILTO ? `&mailto=${encodeURIComponent(process.env.OPENALEX_MAILTO)}` : '';
    const [oa, cr] = await Promise.allSettled([
      fetch(`https://api.openalex.org/works?search=${encodeURIComponent(q)}&per-page=10${mailto}`,{headers:{'User-Agent':'NOVA-Development/1.0'}}).then(r=>r.ok?r.json():Promise.reject()),
      fetch(`https://api.crossref.org/works?query=${encodeURIComponent(q)}&rows=10`).then(r=>r.ok?r.json():Promise.reject())
    ]);
    const openalex = oa.status==='fulfilled' ? (oa.value.results||[]).map(x=>({source:'OpenAlex',title:x.title,year:x.publication_year,doi:x.doi,url:x.doi || x.id,authors:(x.authorships||[]).slice(0,4).map(a=>a.author?.display_name).filter(Boolean)})) : [];
    const crossref = cr.status==='fulfilled' ? (cr.value.message?.items||[]).map(x=>({source:'Crossref',title:x.title?.[0],year:x.published?.['date-parts']?.[0]?.[0],doi:x.DOI,url:x.URL,authors:(x.author||[]).slice(0,4).map(a=>[a.given,a.family].filter(Boolean).join(' '))})) : [];
    const results = [...openalex,...crossref].filter(x=>x.title);
    res.json({query:q,results,warning:results.length?'Vérifiez les métadonnées et consultez la publication originale.':'Aucun résultat récupéré ou sources temporairement indisponibles.'});
  } catch { res.status(502).json({error:'Recherche scientifique temporairement indisponible.'}); }
});
export default router;
