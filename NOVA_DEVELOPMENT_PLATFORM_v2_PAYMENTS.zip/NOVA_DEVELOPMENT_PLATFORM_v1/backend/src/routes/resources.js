import { Router } from 'express';
import { prisma } from '../db.js';
import { authenticate } from '../middleware.js';
import { resourceSchema } from '../validation.js';

const router = Router();
const types = {
  problems:'PROBLEM', ideas:'IDEA', projects:'PROJECT', experts:'EXPERT',
  funding:'FUNDING', courses:'COURSE', impact:'IMPACT'
};
router.use(authenticate);

router.get('/:type', async (req,res,next) => {
  try {
    const type = types[req.params.type];
    if (!type) return res.status(404).json({ error:'Type de ressource inconnu.' });
    const page = Math.max(1, Number(req.query.page) || 1);
    const limit = Math.min(50, Math.max(1, Number(req.query.limit) || 20));
    const where = { type, ...(req.query.status ? {status:String(req.query.status)} : {}) };
    const [items,total] = await Promise.all([
      prisma.resource.findMany({ where, include:{author:{select:{id:true,displayName:true,role:true}}}, orderBy:{createdAt:'desc'}, skip:(page-1)*limit, take:limit }),
      prisma.resource.count({where})
    ]);
    res.json({ items, pagination:{page,limit,total,pages:Math.ceil(total/limit)} });
  } catch(e){ next(e); }
});
router.post('/:type', async (req,res,next) => {
  try {
    const type = types[req.params.type];
    if (!type) return res.status(404).json({error:'Type de ressource inconnu.'});
    const parsed = resourceSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({error:'Données invalides.',details:parsed.error.flatten()});
    const item = await prisma.resource.create({data:{...parsed.data,type,authorId:req.user.id}});
    res.status(201).json({item});
  } catch(e){next(e);}
});
router.get('/:type/:id', async (req,res,next) => {
  try {
    const type = types[req.params.type];
    if (!type) return res.status(404).json({error:'Type inconnu.'});
    const item = await prisma.resource.findFirst({where:{id:req.params.id,type},include:{author:{select:{id:true,displayName:true,role:true}}}});
    if (!item) return res.status(404).json({error:'Ressource introuvable.'});
    res.json({item});
  } catch(e){next(e);}
});
router.patch('/:type/:id', async (req,res,next) => {
  try {
    const type = types[req.params.type];
    if (!type) return res.status(404).json({error:'Type inconnu.'});
    const item = await prisma.resource.findFirst({where:{id:req.params.id,type}});
    if (!item) return res.status(404).json({error:'Ressource introuvable.'});
    if (item.authorId !== req.user.id && !['OWNER','ADMIN','MODERATOR'].includes(req.user.role)) return res.status(403).json({error:'Vous ne pouvez pas modifier cette ressource.'});
    const parsed = resourceSchema.partial().safeParse(req.body);
    if (!parsed.success) return res.status(400).json({error:'Données invalides.',details:parsed.error.flatten()});
    const updated = await prisma.resource.update({where:{id:item.id},data:parsed.data});
    res.json({item:updated});
  } catch(e){next(e);}
});
router.delete('/:type/:id', async (req,res,next) => {
  try {
    const type = types[req.params.type];
    if (!type) return res.status(404).json({error:'Type inconnu.'});
    const item = await prisma.resource.findFirst({where:{id:req.params.id,type}});
    if (!item) return res.status(404).json({error:'Ressource introuvable.'});
    if (item.authorId !== req.user.id && !['OWNER','ADMIN'].includes(req.user.role)) return res.status(403).json({error:'Vous ne pouvez pas supprimer cette ressource.'});
    await prisma.resource.delete({where:{id:item.id}});
    res.json({ok:true});
  } catch(e){next(e);}
});
export default router;
