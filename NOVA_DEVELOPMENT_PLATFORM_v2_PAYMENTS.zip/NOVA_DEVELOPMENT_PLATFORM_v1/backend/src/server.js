import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { prisma } from './db.js';
import authRoutes from './routes/auth.js';
import resourceRoutes from './routes/resources.js';
import aiRoutes from './routes/ai.js';
import researchRoutes from './routes/research.js';
import adminRoutes from './routes/admin.js';
import paymentRoutes from './payments/routes.js';

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  console.error('JWT_SECRET doit contenir au moins 32 caractères.');
  process.exit(1);
}
const app=express();
app.disable('x-powered-by');
app.set('trust proxy',1);
app.use(helmet());
const origins=(process.env.CORS_ORIGIN||'http://localhost:5500').split(',').map(x=>x.trim());
app.use(cors({origin:(origin,cb)=>!origin||origins.includes(origin)?cb(null,true):cb(new Error('Origin not allowed')),credentials:false}));
app.use(express.json({limit:'1mb'}));
app.use(rateLimit({windowMs:15*60*1000,limit:300,standardHeaders:true,legacyHeaders:false}));
app.get('/api/health',async(req,res)=>{
  try{await prisma.$queryRaw`SELECT 1`;res.json({status:'ok',service:'nova-development-api',database:'connected',time:new Date().toISOString()});}
  catch{res.status(503).json({status:'degraded',database:'unavailable'});}
});
app.use('/api/auth',rateLimit({windowMs:15*60*1000,limit:20,standardHeaders:true,legacyHeaders:false}),authRoutes);
app.use('/api/resources',resourceRoutes);
app.use('/api/ai',aiRoutes);
app.use('/api/research',researchRoutes);
app.use('/api/admin',adminRoutes);
app.use('/api/payments',paymentRoutes);
app.use((req,res)=>res.status(404).json({error:'Route introuvable.'}));
app.use((err,req,res,next)=>{
  console.error(err);
  if(err.message==='Origin not allowed') return res.status(403).json({error:'Origine non autorisée.'});
  res.status(500).json({error:'Erreur interne.'});
});
const port=Number(process.env.PORT)||4000;
const server=app.listen(port,()=>console.log(`NOVA API écoute sur le port ${port}`));
async function shutdown(){server.close(async()=>{await prisma.$disconnect();process.exit(0);});}
process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);
