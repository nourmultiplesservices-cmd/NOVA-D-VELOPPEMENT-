import { z } from 'zod';
export const registerSchema = z.object({
  email: z.string().email().max(254),
  password: z.string().min(12).max(128),
  displayName: z.string().trim().min(2).max(80),
  preferredLanguage: z.enum(['fr','en','ar','pt','es','zh','sw','ha','de','hi','yo','ja','tr','ru']).default('fr')
});
export const loginSchema = z.object({ email: z.string().email(), password: z.string().min(1).max(128) });
export const resourceSchema = z.object({
  title: z.string().trim().min(3).max(180),
  description: z.string().trim().min(1).max(20000),
  language: z.string().min(2).max(5).default('fr'),
  country: z.string().max(100).optional().nullable(),
  category: z.string().max(100).optional().nullable(),
  status: z.string().max(40).optional(),
  metadata: z.record(z.any()).optional()
});
