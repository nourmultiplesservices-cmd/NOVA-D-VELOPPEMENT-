# Déploiement de production — guide opératoire

## 1. Choisir le fournisseur
Comparer un VPS managé ou une plateforme applicative avec PostgreSQL managé dans une région
adaptée aux obligations de protection des données. Vérifier localisation, sauvegardes, SLA,
support, coût de sortie et possibilité d'exporter les données.

## 2. Préparer les ressources
- Domaine détenu par la société.
- Service backend Node.js.
- Base PostgreSQL privée, non exposée publiquement.
- Stockage objet privé si les pièces jointes sont ajoutées.
- HTTPS/TLS et DNS.
- Surveillance, alertes et sauvegardes chiffrées.

## 3. Secrets
Configurer dans le gestionnaire de secrets du fournisseur :
DATABASE_URL, JWT_SECRET, JWT_EXPIRES_IN, CORS_ORIGIN,
OWNER_EMAIL, OWNER_PASSWORD, AI_BASE_URL, AI_API_KEY, AI_MODEL.
Ne jamais placer ces secrets dans le frontend, Git ou un fichier public.

## 4. Base de données
Exécuter les migrations Prisma dans le pipeline de déploiement :
`npx prisma migrate deploy`
Puis exécuter une seule fois l'amorçage propriétaire :
`npm run owner:bootstrap`
Le mot de passe initial doit être unique et stocké dans un gestionnaire de mots de passe.

## 5. Contrôles avant ouverture
- HTTPS actif et redirection HTTP vers HTTPS.
- CORS limité au domaine réel.
- PostgreSQL accessible uniquement depuis le backend.
- MFA à ajouter au parcours propriétaire avant ouverture publique.
- Sauvegarde et restauration testées.
- Tests de sécurité et de charge.
- Politique de confidentialité, conditions d'utilisation et processus de suppression des comptes.
- Tests de toutes les langues par des locuteurs compétents.
- Vérification des licences et conditions d'utilisation des sources scientifiques et IA.

## 6. Mise en production progressive
Déployer d'abord en environnement staging, inviter un petit groupe pilote, corriger les anomalies,
puis ouvrir progressivement. Prévoir un plan de retour à la version précédente.

Ce guide n'effectue pas lui-même le déploiement : il faut disposer du compte cloud, du domaine
et des secrets de production.


## Blueprint fourni
Le fichier `render.yaml` à la racine décrit la base PostgreSQL, le backend Node et le frontend statique.
Avant de lancer le Blueprint, vérifier les plans et la région disponibles dans le compte Render. Le plan PostgreSQL d'entrée de gamme et le plan Starter sont des points de départ, pas une capacité garantie pour le trafic mondial.
Après création du service, renseigner les variables `CORS_ORIGIN`, `OWNER_EMAIL`, `OWNER_PASSWORD` et les secrets IA dans le Dashboard.
Pour le frontend, renseigner `NOVA_API_URL` dans la configuration du site si le fournisseur expose cette variable au build, ou remplacer `window.NOVA_API_URL` dans `frontend/config.js` par l'URL API Render obtenue, puis redéployer.
Le compte propriétaire est créé par le script `npm run owner:bootstrap` depuis un environnement backend connecté à la base. Ne pas exécuter ce script à chaque démarrage.
