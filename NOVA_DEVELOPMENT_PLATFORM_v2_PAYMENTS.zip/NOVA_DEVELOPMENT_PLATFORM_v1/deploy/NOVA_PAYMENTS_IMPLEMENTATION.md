# NOVA PAYMENTS — plan d’implémentation technique

## Décisions produit
- Accès Free limité ; offres Pro et Business mensuelles et annuelles.
- Mobile Money direct : Wave, Orange Money, MTN MoMo.
- Visa/Mastercard : prestataire carte certifié avec page de paiement hébergée/tokenisation ; aucun PAN/CVV stocké par NOVA.
- Architecture mondiale, activation réelle pays/devise/prestataire après validation KYC, contrats et tests.

## État de ce paquet
Le schéma Prisma, les routes de consultation des offres, la création de checkout et l’historique utilisateur sont ajoutés. Les adaptateurs Wave, Orange, MTN et cartes sont volontairement désactivés (fail closed). Aucun paiement réel ne peut être encaissé avec cette version. Les connecteurs ne doivent être activés qu’après implémentation des contrats API exacts, vérification des signatures webhooks, sandbox et homologation marchand.

## Étapes d’implémentation
1. Exécuter `npm run prisma:generate`, créer/appliquer une migration Prisma, puis `npm run payments:seed`.
2. Obtenir les comptes marchands et accès développeur au nom de l'entité exploitante. Vérifier les pays, devises, commissions, délais de règlement, remboursements et exigences KYC.
3. Implémenter chaque provider selon sa documentation officielle et son environnement.
4. Pour Wave : Checkout Sessions, statut serveur, webhooks avec secret/signature, idempotence, expiration et remboursement. Ne jamais exposer l’API key au navigateur.
5. Pour Orange Money : API Web Payment du pays marchand, OAuth/identifiants et mécanisme de callback fournis dans l’onboarding Orange. Le service est réservé aux marchands agréés.
6. Pour MTN MoMo : Collections RequestToPay, OAuth, X-Reference-Id UUID unique, X-Target-Environment, callback et polling du statut. Le HTTP 202 indique une demande acceptée, pas un paiement réussi.
7. Pour Visa/Mastercard : sélectionner un acquéreur/prestataire compatible avec le pays d’établissement et les pays clients ; utiliser hosted checkout/hosted fields, 3-D Secure et gestion des contestations.
8. Construire un service commun de transition de statut : seul un événement authentifié ou une vérification serveur du prestataire peut passer un paiement à SUCCEEDED.
9. Sur succès : transaction DB atomique, création/activation de Subscription, Invoice et écriture du journal financier. Les événements webhook sont dédupliqués.
10. Ajouter tâches de rapprochement, vérification des paiements en attente, remboursements, exports comptables et alertes.
11. Effectuer tests sandbox, tests de rejeu webhook, doublons, montants altérés, remboursements, échecs et restauration DB.
12. Revue sécurité indépendante et autorisation de mise en production.

## Contrat des adaptateurs
Chaque adaptateur doit exposer `isConfigured()`, `createCheckout(payment, customer)`, `verifyWebhook(request)` et `getPaymentStatus(providerPaymentId)`. `verifyWebhook` doit authentifier le corps brut selon le mécanisme exact du fournisseur ; ne jamais supposer que tous les fournisseurs utilisent HMAC identique.

## Règles essentielles
- Ne jamais faire confiance au navigateur ni à une URL success.
- Vérifier montant, devise, référence interne et identité du marchand côté serveur.
- Idempotence sur création et webhooks ; contraintes uniques en base.
- Conserver les montants en unités mineures entières (BigInt), jamais en float.
- Pour XOF, aucun chiffre décimal.
- Ne pas confondre chiffre d’affaires, frais, remboursements et versements nets.
- Les renouvellements automatiques ne sont activés que si le moyen de paiement et le contrat du prestataire les autorisent. Pour Mobile Money, prévoir une nouvelle autorisation de paiement si nécessaire.
- Une souscription n’est active qu’après paiement confirmé.
- Le pays, la devise et le prestataire sont une matrice de disponibilité configurable.

## Limites à résoudre avant production
- Les tarifs annuels de seed sont des exemples de configuration à valider commercialement.
- Le code de ce paquet n'implémente pas encore les appels API réels ni les webhooks.
- Le modèle de facturation doit être adapté aux obligations fiscales et comptables des pays visés.
- Les remboursements et paiements récurrents nécessitent les capacités contractuelles du prestataire.
