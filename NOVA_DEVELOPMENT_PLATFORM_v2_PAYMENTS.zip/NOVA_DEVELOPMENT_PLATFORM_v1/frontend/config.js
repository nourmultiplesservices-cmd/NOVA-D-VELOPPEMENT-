// After deploying the backend, replace the URL below with your Render API URL.
window.NOVA_API_URL = 'https://REPLACE-WITH-YOUR-API.onrender.com/api';
